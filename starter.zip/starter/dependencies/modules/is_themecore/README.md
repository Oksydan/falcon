# Theme core module  
Prestashop module created for [starter theme](https://github.com/Oksydan/modern-prestashop-starter-theme)
