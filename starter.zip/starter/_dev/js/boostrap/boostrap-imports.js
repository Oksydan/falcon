import 'bootstrap/js/dist/alert.js';
import 'bootstrap/js/dist/button.js';
import 'bootstrap/js/dist/tab.js';
import 'bootstrap/js/dist/util.js';

// MOVED TO DYNAMIC IMPORTS
// import 'bootstrap/js/dist/carousel.js';
// import 'bootstrap/js/dist/collapse.js';
// import 'bootstrap/js/dist/dropdown.js';
// import 'bootstrap/js/dist/modal.js';
// import 'bootstrap/js/dist/popover.js';
// import 'bootstrap/js/dist/scrollspy.js';
// import 'bootstrap/js/dist/toast.js';
